package com.phase1.LockedMeApplication;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class RetrieveFile {
    List<String> list= new ArrayList<String>();
    File[] files = new File("path").listFiles();
    public void showFiles() {
        for (File file : files) {
            if (file.isFile()) {
                list.add(file.getName());
            }
        }
        System.out.println("Displaying all files in ascending order\n");
        Collections.sort(list);
        list.stream().forEach(System.out::println);
    }
}
