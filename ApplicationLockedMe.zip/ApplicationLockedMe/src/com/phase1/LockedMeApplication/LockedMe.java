package com.phase1.LockedMeApplication;
import java.util.Scanner;
public class LockedMe {
    public static void main(String[] args) {
        boolean running = true;
        System.out.println("Welcome to LockedMe.com");
        System.out.println("This is developed by Maheshwari");
        BusinessLevelOperations b = new BusinessLevelOperations();
        RetrieveFile r=new RetrieveFile();
        int a = 0;
        try {
            do {
                System.out.println("What actions you want to do..?");
                System.out.println("\t1. For retrieving the file name:");
                System.out.println("\t2. For business-level operations:");
                System.out.println("\t3. To Close the Application:");
                Scanner sc = new Scanner(System.in);
                a = sc.nextInt();
                switch (a) {
                    case 1:
                        r.showFiles();
                        break;
                    case 2:
                        System.out.println("Business-Level Operation:");
                        int s;
                        do {
                            System.out.println("Enter your choice for Business level operation");
                            System.out.println("\t1. Add a file and its content to a directory");
                            System.out.println("\t2. Delete a file from a directory");
                            System.out.println("\t3. Searching a file and showing its content");
                            System.out.println("\t4. Exit from BOL menu");
                            s = sc.nextInt();
                            switch (s) {
                                case 1:
                                    b.addFile();
                                    break;
                                case 2:
                                    b.deleteFile();

                                    break;
                                case 3:
                                    b.searchFile();
                                    break;
                                case 4:
                                    System.out.println("Exit from Business Level operation.");
                                    break;
                                default:
                                    System.out.println("Invalid Choice. Please select a valid option.");
                                    break;
                            }
                        } while (s != 4);
                        break;
                    case 3:
                        System.out.println("Exit from the Application.");
                        System.out.println("Program exited successfully.");
                        running=false;
                        sc.close();
                        System.exit(0);
                    default:
                        System.out.println("Please select a valid option from above.");
                }
            } while (a != 3);
        } catch (Exception e) {
            e.printStackTrace();
            e.getMessage();

        }while (running == true);

    }
}


